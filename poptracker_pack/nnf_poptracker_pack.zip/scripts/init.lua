Tracker:AddItems("items/items.json")
Tracker:AddLocations("locations/locations.json")
Tracker:AddLayouts("layouts/layouts.json")
ScriptHost:LoadScript("scripts/autotracking.lua")
